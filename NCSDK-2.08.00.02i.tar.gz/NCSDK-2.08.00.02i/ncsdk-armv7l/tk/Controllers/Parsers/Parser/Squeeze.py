# Copyright 2018 Intel Corporation.
# The source code, information and material ("Material") contained herein is
# owned by Intel Corporation or its suppliers or licensors, and title to such
# Material remains with Intel Corporation or its suppliers or licensors.
# The Material contains proprietary information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright laws and treaty
# provisions.
# No part of the Material may be used, copied, reproduced, modified, published,
# uploaded, posted, transmitted, distributed or disclosed in any way without
# Intel's prior express written permission. No license under any patent,
# copyright or other intellectual property rights in the Material is granted to
# or conferred upon you, either expressly, by implication, inducement, estoppel
# or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

import operator

from Controllers.Parsers.Parser.Permute import Permute
from .Layer import Layer
import Models.Layouts as Layouts
from Controllers.TensorFormat import TensorFormat
from Controllers.EnumController import throw_error
from Models.EnumDeclarations import ErrorTable


class Squeeze(Permute):
    # FromLayout -> TF -> Squeeze -> TF -> ToLayout
    #
    # (FromLayout, ToLayout, (sq_axis_0, sq_axis_1, sq_axis_2)) : Permutation
    #
    SqueezePermutations = \
        {(Layouts.NHCW, Layouts.NHCW, (False, False, False)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHCW, (False, False, False)): (0, 2, 1),
         (Layouts.NCHW, Layouts.NHCW, (False, False, False)): (0, 2, 1),

         (Layouts.NHCW, Layouts.NHWC, (False, False, False)): (0, 2, 1),
         (Layouts.NHWC, Layouts.NHWC, (False, False, False)): (0, 2, 1),
         (Layouts.NCHW, Layouts.NHWC, (False, False, False)): (0, 2, 1),

         (Layouts.NHCW, Layouts.NCHW, (False, False, False)): (1, 0, 2),
         (Layouts.NHWC, Layouts.NCHW, (False, False, False)): (2, 0, 1),
         (Layouts.NCHW, Layouts.NCHW, (False, False, False)): (1, 2, 0),

         (Layouts.NHCW, Layouts.NHCW, (False, False, True)): (0, 2, 1),
         (Layouts.NHWC, Layouts.NHCW, (False, False, True)): (0, 2, 1),
         (Layouts.NCHW, Layouts.NHCW, (False, False, True)): (0, 2, 1),

         (Layouts.NHCW, Layouts.NHWC, (False, False, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHWC, (False, False, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NHWC, (False, False, True)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NCHW, (False, False, True)): (2, 0, 1),
         (Layouts.NHWC, Layouts.NCHW, (False, False, True)): (2, 0, 1),
         (Layouts.NCHW, Layouts.NCHW, (False, False, True)): (1, 0, 2),

         (Layouts.NHCW, Layouts.NHCW, (False, True, False)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHCW, (False, True, False)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NHCW, (False, True, False)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NHWC, (False, True, False)): (0, 2, 1),
         (Layouts.NHWC, Layouts.NHWC, (False, True, False)): (0, 2, 1),
         (Layouts.NCHW, Layouts.NHWC, (False, True, False)): (0, 2, 1),

         (Layouts.NHCW, Layouts.NCHW, (False, True, False)): (1, 0, 2),
         (Layouts.NHWC, Layouts.NCHW, (False, True, False)): (1, 0, 2),
         (Layouts.NCHW, Layouts.NCHW, (False, True, False)): (2, 0, 1),

         (Layouts.NHCW, Layouts.NHCW, (True, False, False)): (2, 0, 1),
         (Layouts.NHWC, Layouts.NHCW, (True, False, False)): (1, 0, 2),
         (Layouts.NCHW, Layouts.NHCW, (True, False, False)): (1, 0, 2),

         (Layouts.NHCW, Layouts.NHWC, (True, False, False)): (2, 1, 0),
         (Layouts.NHWC, Layouts.NHWC, (True, False, False)): (2, 1, 0),
         (Layouts.NCHW, Layouts.NHWC, (True, False, False)): (2, 1, 0),

         (Layouts.NHCW, Layouts.NCHW, (True, False, False)): (0, 2, 1),
         (Layouts.NHWC, Layouts.NCHW, (True, False, False)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NCHW, (True, False, False)): (1, 2, 0),

         (Layouts.NHCW, Layouts.NHCW, (False, True, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHCW, (False, True, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NHCW, (False, True, True)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NHWC, (False, True, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHWC, (False, True, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NHWC, (False, True, True)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NCHW, (False, True, True)): (1, 0, 2),
         (Layouts.NHWC, Layouts.NCHW, (False, True, True)): (1, 0, 2),
         (Layouts.NCHW, Layouts.NCHW, (False, True, True)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NHCW, (True, True, False)): (2, 0, 1),
         (Layouts.NHWC, Layouts.NHCW, (True, True, False)): (2, 0, 1),
         (Layouts.NCHW, Layouts.NHCW, (True, True, False)): (2, 0, 1),

         (Layouts.NHCW, Layouts.NHWC, (True, True, False)): (2, 0, 1),
         (Layouts.NHWC, Layouts.NHWC, (True, True, False)): (2, 0, 1),
         (Layouts.NCHW, Layouts.NHWC, (True, True, False)): (2, 0, 1),

         (Layouts.NHCW, Layouts.NCHW, (True, True, False)): (0, 2, 1),
         (Layouts.NHWC, Layouts.NCHW, (True, True, False)): (0, 2, 1),
         (Layouts.NCHW, Layouts.NCHW, (True, True, False)): (2, 0, 1),

         (Layouts.NHCW, Layouts.NHCW, (True, False, True)): (1, 0, 2),
         (Layouts.NHWC, Layouts.NHCW, (True, False, True)): (1, 0, 2),
         (Layouts.NCHW, Layouts.NHCW, (True, False, True)): (1, 0, 2),

         (Layouts.NHCW, Layouts.NHWC, (True, False, True)): (1, 0, 2),
         (Layouts.NHWC, Layouts.NHWC, (True, False, True)): (1, 0, 2),
         (Layouts.NCHW, Layouts.NHWC, (True, False, True)): (1, 0, 2),

         (Layouts.NHCW, Layouts.NCHW, (True, False, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NCHW, (True, False, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NCHW, (True, False, True)): (1, 0, 2),

         (Layouts.NHCW, Layouts.NHCW, (True, True, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHCW, (True, True, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NHCW, (True, True, True)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NHWC, (True, True, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NHWC, (True, True, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NHWC, (True, True, True)): (0, 1, 2),

         (Layouts.NHCW, Layouts.NCHW, (True, True, True)): (0, 1, 2),
         (Layouts.NHWC, Layouts.NCHW, (True, True, True)): (0, 1, 2),
         (Layouts.NCHW, Layouts.NCHW, (True, True, True)): (0, 1, 2)
         }

    def __init__(self, *args):
        super().__init__(*args)

    def get_mvtensor_permutation(self, input_layout, output_layout):

        squeeze_axes = [False, False, False]
        squeeze_axes_tf = [False, False, False]

        if 0 in self.get_squeezed_dims():
            throw_error(ErrorTable.UnsupportedOperation, "Cannot squeeze batch axis")

        for i in self.get_squeezed_dims():
            squeeze_axes_tf[i-1] = True
        # squeeze_axes_tf is in TF format (NHWC => HWC)

        # planar == NCHW 0123
        input_size_planar = self.getInputTensorSizes()[0]

        if input_layout == Layouts.NHCW:
            input_size_converted = [input_size_planar[0], input_size_planar[2], input_size_planar[1], input_size_planar[3]]
            squeeze_axes = [squeeze_axes_tf[0], squeeze_axes_tf[2], squeeze_axes_tf[1]]
        elif input_layout == Layouts.NHWC:
            input_size_converted = [input_size_planar[0], input_size_planar[2], input_size_planar[3], input_size_planar[1]]
            squeeze_axes = squeeze_axes_tf
        elif input_layout == Layouts.NCHW:
            input_size_converted = input_size_planar
            squeeze_axes = [squeeze_axes_tf[1], squeeze_axes_tf[2], squeeze_axes_tf[0]]
        else:
            throw_error(ErrorTable.UnsupportedOperation, "Squeeze only supports input layout of NHCW / NHWC / NCHW")

        may_be_squeezed = [input_size_converted[1] == 1, input_size_converted[2] == 1, input_size_converted[3] == 1]

        squeeze_these_axes = [x and y for x, y in zip(squeeze_axes, may_be_squeezed)]

        perm_tuple = self.SqueezePermutations[(input_layout, output_layout, tuple(squeeze_these_axes))]
        permutation = [perm_tuple[0], perm_tuple[1], perm_tuple[2]]
        return permutation

    def set_squeezed_dims(self, squeezed_dims):
        self.squeezeddims = squeezed_dims

    def get_squeezed_dims(self):
        return self.squeezeddims
