#!/usr/bin/env python3

from Controllers.Parsers.Parser.tan_h import TanH

def load(obj, parsedNetworkObj):

    x = TanH(obj.name, obj.bottom, obj.top)

    return [x]