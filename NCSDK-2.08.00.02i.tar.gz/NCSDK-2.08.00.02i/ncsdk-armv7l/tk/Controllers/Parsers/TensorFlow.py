# Copyright 2017 Intel Corporation.
# The source code, information and material ("Material") contained herein is
# owned by Intel Corporation or its suppliers or licensors, and title to such
# Material remains with Intel Corporation or its suppliers or licensors.
# The Material contains proprietary information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright laws and treaty
# provisions.
# No part of the Material may be used, copied, reproduced, modified, published,
# uploaded, posted, transmitted, distributed or disclosed in any way without
# Intel's prior express written permission. No license under any patent,
# copyright or other intellectual property rights in the Material is granted to
# or conferred upon you, either expressly, by implication, inducement, estoppel
# or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.


import os
import subprocess
import tempfile
import sys

# Tensorflow 1.7 has some deprecated features that result in warnings when it is
# imported. Suppress these warnings until TF resolves them.
import warnings
with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)
    import tensorflow as tf

import google.protobuf as proto
import numpy as np
import networkx as nx

from collections import OrderedDict
import math
import re
from tensorflow.core.framework import graph_pb2
from tensorflow.python.framework import ops

from Models.EnumDeclarations import SeedData

from Controllers.EnumController import throw_error, ErrorTable, compiler_assert
from Controllers.Parsers.Parser.Layer import OriginalName, MangledName
from Controllers.Parsers.Parser.Output import Output
from Controllers.Parsers.Parser.DetectionOutput import DetectionOutput
from Controllers.Parsers.Parser.Bias import Bias
from Controllers.Parsers.Parser.Convolution2D import Convolution2D, ConvolutionDepthWise2D

from Controllers.Parsers import TensorFlowParser as tfp
from Controllers.Tensor import UnpopulatedTensor

from Controllers.Preprocess import preprocess
from Controllers.MiscIO import parse_img, preprocess_img
from Controllers.GraphUtils import buildGraph, buildLayerLists

RAND_HI = 1
RAND_LO = -1

debug = False


# TensorFlow files contain many nodes that are not relevant to inference.  This
# function removes all layers that are not ancecstors of the output layers.
def pruneNodes(parsedLayers, output_node_name):
    outputMangledNames = [layer.getName().stringifyName() for layer in 
                        parsedLayers if layer.getName().stringifyOriginalName() == output_node_name]
    g = buildGraph(parsedLayers)
    outputNode = outputMangledNames[0]
    croppedNodes = nx.ancestors(g, outputNode)
    croppedNodes.add(outputNode)
    croppedGraph = nx.subgraph(g, croppedNodes)
    croppedLayers = buildLayerLists(croppedGraph)
    return croppedLayers


def regularizeInPlaceOps(parsedLayers):
    # Some operations in Caffe can be inplace. Introduce new names for these layers
    inPlaceOps = OrderedDict()
    tensorProducer = OrderedDict()
    for layer in parsedLayers:
        for i in layer.getOutputTensorNames():
            try:
                tensorProducer[i.stringifyName()].append(layer)
            except:
                tensorProducer[i.stringifyName()] = [layer]

        if set(layer.getOutputTensorNames()).intersection(set(layer.getInputTensorNames())):
            assert(len(layer.getOutputTensorNames()) == 1)

            tensorName = layer.getOutputTensorNames()[0]
            try:
                inPlaceOps[tensorName.stringifyName()].append(layer)
            except:
                inPlaceOps[tensorName.stringifyName()] = [layer]

    def remangleName(mangledNameList, matchingName):
        for idx, n in enumerate(mangledNameList):
            if n.stringifyName() == matchingName:
                newName = n.remangle()
                mangledNameList[idx] = newName
                return newName

    def replaceName(mangledNameList, matchingName, newName):
        for idx, n in enumerate(mangledNameList):
            if n.stringifyName() == matchingName:
                mangledNameList[idx] = newName

    for tensorName, layerGroup in inPlaceOps.items():
        extendedList = list(set(tensorProducer[tensorName]).difference(set(layerGroup)))
        extendedList.extend(layerGroup[:-1])
        for producer, consumer in zip(extendedList, layerGroup):
            newName = remangleName(producer.getOutputTensorNames(), tensorName)
            replaceName(consumer.getInputTensorNames(), tensorName, newName)

    return parsedLayers

def createTensors(parsedLayers):
    # Collect all the tensorNames and sizes
    tensorNames = OrderedDict()
    for layer in parsedLayers:
        for tensorName, tensorSize in zip(layer.getInputTensorNames(), layer.getInputTensorSizes()):
            if tensorName.stringifyName() not in tensorNames:
                tensorNames[tensorName.stringifyName()] = UnpopulatedTensor(tensorSize)
                tensorNames[tensorName.stringifyName()].setName(tensorName)

        for tensorName, tensorSize in zip(layer.getOutputTensorNames(), layer.getOutputTensorSizes()):
            if tensorName.stringifyName() not in tensorNames:
                tensorNames[tensorName.stringifyName()] = UnpopulatedTensor(tensorSize)
                tensorNames[tensorName.stringifyName()].setName(tensorName)

    for layer in parsedLayers:
        layer.setInputTensors([tensorNames[n.stringifyName()] for n in layer.getInputTensorNames()])
        layer.setOutputTensors([tensorNames[n.stringifyName()] for n in layer.getOutputTensorNames()])

def insertOutputOps(parsedLayers, output_name):
    # Find all tensors that are not consumed by anybody
    tensorNames = OrderedDict()
    for layer in parsedLayers:
        for tensor in layer.getInputTensors():
            if tensor.getName().stringifyName() not in tensorNames:
                tensorNames[tensor.getName().stringifyName()] = ([0, 0], tensor, [])

            tensorNames[tensor.getName().stringifyName()][0][0] += 1

        for tensor in layer.getOutputTensors():
            if tensor.getName().stringifyName() not in tensorNames:
                tensorNames[tensor.getName().stringifyName()] = ([0, 0], tensor, [])

            tensorNames[tensor.getName().stringifyName()][0][1] += 1
            tensorNames[tensor.getName().stringifyName()][2].append(layer)

    for tensorName, tensorValue in tensorNames.items():
        consumersAndProducers, tensor, producers = tensorValue
        consumers = consumersAndProducers[0]
        if consumers == 0 and tensor.getName().stringifyOriginalName() == output_name:
            x = Output('output', [tensor.getName()], [])
            x.setInputTensors([tensor])
            x.setOutputTensors([])
            x.loadInputTensorSizes([tensor.getShape()])
            x.loadOutputTensorSizes([])

            assert(len(producers) == 1)
            if isinstance(producers[0], DetectionOutput):
                x.enableDetectionOutput()

            parsedLayers.append(x)

    return parsedLayers

def printLayers(layers):
    for layer in layers:
        print('Node:', layer)
        print('  layer name:', layer.getStringifiedName())
        print('  input tensors:', )
        for tensorName in layer.getInputTensorNames():
            print('    ', tensorName.stringifyName())
        print('  output tensors:')
        for tensorName in layer.getOutputTensorNames():
            print('    ', tensorName.stringifyName())


def getDirectAncestorOps(ops):
    directAncestorOps = []
    for o in ops:
        directAncestorOps += [i.op for i in o.inputs]
    return directAncestorOps

def opIsNonConstant(op, input_obj, parsedLayers):
    # Consider that an op is constant (i.e. producing a tensor that can
    # be evaluated/computed at compile time) when it has no direct
    # path to the 'input' node

    if (op == input_obj):
        return True

    # 1. check if any of the direct ancestors is already parsed
    parsedOpsNames = [p.getStringifiedOriginalName() for p in parsedLayers]
    iterate = True
    parentOps = [op]
    while len(parentOps) > 0:
        parentOps = getDirectAncestorOps(parentOps)
        parentOpsNames = [p.name for p in parentOps]

        if any(pName in parsedOpsNames for pName in parentOpsNames):
            # Parent is already parsed, hence the operation is non-constant
            return True

    return False

class TensorFlowParser:
    
    def __init__(self):
        self.type = 'TensorFlow'
        self.model = None
        self.feed_dict = None
    
    def getType(self):
        return self.type
    
    # calculate the reference output of the graph to compare with myriad results
    def calculateReference(self, arguments):

        image = arguments.image
        input_node_name = arguments.input_node_name
        output_node_name = arguments.output_node_name
        inputnode = 'input'

        if input_node_name is not None:
            inputnode = input_node_name
        if output_node_name is None:
            output_node_name = 'output'

        with self.session.as_default():
            try:
                inputTensor = self.model.get_tensor_by_name(inputnode + ':0')
            except:
                throw_error(ErrorTable.NoOutputNode, inputnode)

            try:
                outputTensor = self.model.get_tensor_by_name(output_node_name + ':0')
            except:
                throw_error(ErrorTable.NoOutputNode, output_node_name)
            print("output tensor shape", outputTensor.get_shape())

            shape = inputTensor.get_shape()
            input_shape = shape
            if isinstance(shape, tf.TensorShape):
                shape_list = shape.as_list()
                # Tensorflow can have None in the batch size field of the
                # input shape, if that is the case then set it to 1
                if None == shape_list[0]:
                    shape_list[0] = 1
                    shape = shape_list
                    inputTensor.set_shape(shape)
                elif None in shape:
                    print("No shape information for tensor")

            if image is None or ((image is not None) and image.startswith("Debug")):
                # input_data = np.random.uniform(0, 1, shape)
                # print("Input image shape", shape)
                # input_data = preprocess_img(input_data,
                #               raw_scale=arguments.raw_scale,
                #               mean=arguments.mean,
                #               channel_swap=arguments.channel_swap)
                #  Select Input

                img = preprocess(image, arguments, input_shape)

                if arguments.seed != -1:
                    np.random.seed(arguments.seed)

                if img is SeedData.all_ones:
                    input_data = np.ones(input_shape)
                elif img is SeedData.all_zeros:
                    input_data = np.zeros(input_shape)
                elif img is SeedData.random or img is None:
                    input_data = np.random.uniform(RAND_LO, RAND_HI, input_shape).astype(dtype=np.float16)
                elif img is SeedData.random_int:
                    input_data = np.random.randint(RAND_LO, RAND_HI, input_shape).astype(dtype=np.float16)
                # never here, kept for future refactoring (as in Caffe)
                else:
                    input_data = img

                input_data = input_data.astype(dtype=np.float16)

            else:
                input_data = parse_img(image,
                                    [int(shape[0]),
                                        int(shape[3]),
                                        int(shape[1]),
                                        int(shape[2])],
                                    raw_scale=arguments.raw_scale,
                                    mean=arguments.mean,
                                    channel_swap=arguments.channel_swap)
                input_data = input_data.transpose([0, 2, 3, 1])

            self.feed_dict = {inputnode + ':0': input_data}
            tf.global_variables_initializer()
            expected_result = outputTensor.eval(self.feed_dict)

            # convert shape
            input_data = np.transpose(input_data, (0, 3, 1, 2))
            if len(expected_result.shape) == 4:
                expected_result = np.transpose(expected_result, (0, 3, 1, 2))
            elif len(expected_result.shape) == 3:
                pass
            elif len(expected_result.shape) == 2:
                expected_result = expected_result.reshape(1, expected_result.shape[1], expected_result.shape[0])
            else:
                expected_result = expected_result.reshape(1, 1, expected_result.shape[0])

        return input_data, expected_result, outputTensor.name


    def loadNetworkObjects(self,graph_path, model_path=None):
        """ Get the tensorflow protobuff model and parse it via tensorflow
        """
        print(graph_path)

        self.session = tf.Session()
        with self.session.as_default():
            filetype = graph_path.split(".")[-1]
            if filetype == 'pb':
                graph_def = graph_pb2.GraphDef()
                with open(graph_path, 'rb') as f:
                    graph_def.ParseFromString(f.read())
                tf.import_graph_def(graph_def, name="")
            else:
                saver = tf.train.import_meta_graph(graph_path, clear_devices=True)
                if saver is not None:
                    #print(graph_path[:graph_path.rfind('.')])
                    saver.restore(self.session, graph_path[:graph_path.rfind('.')])

            self.model = tf.get_default_graph()

            # allow default session for obtaining variable values

        return 

    def parse(self, arguments):

        if arguments.output_node_name is None:
            output_node_name = 'output'
        else:
            output_node_name = arguments.output_node_name

        if arguments.input_node_name is None:
            input_node_name = 'input'
        else:
            input_node_name = arguments.input_node_name

        output_tensor_name = output_node_name + ':0'

        with self.session.as_default():

            filename = arguments.outputs_name

            if debug:
                for idx, node in enumerate(self.model.get_operations()):
                    print("       ", idx, node.type, node.name)
                    for a in node.inputs:
                        print("           IN:", a.name)
                    for a in node.outputs:
                        print("           OUT:", a.name)

            # Define which subparser needs to be called for each layer
            subParsers = {
                'Placeholder': tfp.Placeholder.load,
                'Conv2D': tfp.Convolution.load,
                'DepthwiseConv2dNative': tfp.Convolution.load,
                'MaxPool': tfp.Pooling.load,
                'AvgPool': tfp.Pooling.load,
                'Relu': tfp.ReLU.load,
                'Relu6': tfp.ReLU.load,
                'BiasAdd': tfp.BiasAdd.load,
                'Concat': tfp.Concat.load,
                'ConcatV2': tfp.Concat.load,
                'Identity' : tfp.Identity.load,
                'Slice': tfp.Slice.load,
                'Add': tfp.Math.load,
                'Mul': tfp.Math.load,
                'Sub': tfp.Math.load,
                # 'ELU': tfp.ELU.load,
                # 'PReLU': tfp.PReLU.load,
                'LRN': tfp.LRN.load,
                'MatMul': tfp.MatMul.load,
                'Softmax': tfp.Softmax.load,
                'FusedBatchNorm': tfp.FusedBatchNorm.load,
                # 'Scale': tfp.Scale.load,
                # TODO: Needs to be checked first.
                'Reshape' : tfp.Reshape.load,
                # 'Dropout' : tfp.Dropout.load,
                # 'Squeeze' : tfp.Squeeze.load,
                'Squeeze' : tfp.Identity.load,
                'Pad' : tfp.Pad.load,
                'Maximum' : tfp.Math.load,
                'RealDiv' : tfp.RealDiv.load
            }

            parsedLayers = []
            input_obj = self.model.get_operation_by_name(input_node_name)
            operations = self.model.get_operations()
            for obj in operations:
                if opIsNonConstant(obj, input_obj, parsedLayers):
                    opParser = subParsers.get(obj.type, None)
                    compiler_assert(opParser is not None,
                                ErrorTable.StageTypeNotSupported, obj.type)
                    if opParser is not None:
                        parsedLayers.extend(opParser(obj, operations))
                else:
                    # skip constant tensors
                    pass
                if obj.name == output_node_name:
                    break

            tfp.Helpers.loadTensorSizes(parsedLayers, self.model)

            # Mangle tensor names
            tensorNamesDict = OrderedDict()
            for layer in parsedLayers:
                for tensorName in list(layer.getInputTensorNames()) + list(layer.getOutputTensorNames()):
                    if tensorName not in tensorNamesDict:
                        tensorNamesDict[tensorName] = MangledName(OriginalName(tensorName))

            # Replace tensor names in layers with mangled ones:
            for layer in parsedLayers:
                layer.setInputTensorNames([tensorNamesDict[name] for name in layer.getInputTensorNames()])
                layer.setOutputTensorNames([tensorNamesDict[name] for name in layer.getOutputTensorNames()])

            # Convert inPlace operations into regular ones
            parsedLayers = regularizeInPlaceOps(parsedLayers)

            # Prune subgraphs
            # Is this still necessary after implementing the method with checking
            # for constant OP at parsing time ?
            parsedLayers = pruneNodes(parsedLayers, output_node_name)

            if debug: # print set of layers not yet implemented
                print('Layers not yet implemented:')
                print(set([x.type for x in operations if x.type not in subParsers]))

            # Create tensor objects for each operation
            createTensors(parsedLayers)

            # Introduce Output operations
            parsedLayers = insertOutputOps(parsedLayers, output_tensor_name)

            g = buildGraph(parsedLayers)

            print("Fusing DeptwiseConv + Pointwise Convolution into plain Convolution")
            g = DwSeparableConvToConv2D(g)
            print("Fusing Add and Batch after Convolution")
            g = fuseBiasAdd(g)

            parsedLayers = buildLayerLists(g)

        return parsedLayers
    
    def get_layer_data(self, outBlobName):
        tfModel = self.model  
        sess = self.session  
        feed_dict = self.feed_dict 

        with sess.as_default():
            try:
                outputTensor = tfModel.get_tensor_by_name(outBlobName)
            except:
                print("error getting output tensor")
            out_data = outputTensor.eval(feed_dict)
        
        if (len(out_data.shape) == 4):
            out_data = out_data.transpose((0, 3, 1, 2))
        return out_data


def DwSeparableConvToConv2D(g):
    from Controllers.Optimizer import fuse_nodes
    from Models.EnumDeclarations import PadStyle

    """
        Iterates over the graph detecting sequences of DeptwiseConv2D followed by
        PointwiseConvolution (i.e. 1x1 Convolution), sequence known as
        Deptwise Separable Convolution, into a standard Convolution2D
    """
    def isDepthwiseConv(layer):
        """
            Returns True/False if the given layer is of type ConvolutionDepthWise2D
            and its parameters are qualified for the fusing of separable convolution
        """
        from Controllers.Parsers.Parser.Convolution2D import ConvolutionDepthWise2D

        if type(layer) not in [ConvolutionDepthWise2D]:
            return False
        # weights shape for a DW convolution is [ch_mult, in_ch, fH, fW]
        ch_mult = layer.getWeights().shape[0]
        qualified = ch_mult > 1

        return qualified

    def isPointwiseConv(layer):
        """
            Returns True/False if the given layer is/is not a 1x1 Convolution Layer
        """
        from Controllers.Parsers.Parser.Convolution2D import Convolution2D
        qualified = True
        qualified = qualified and type(layer) in [Convolution2D]
        qualified = qualified and layer.getKernelSize() == (1,1)
        qualified = qualified and \
                     (layer.padStyle == PadStyle.caffe and layer.getPadding() == (0,0) or \
                      layer.padStyle == PadStyle.tfvalid)

        return qualified

    def WeightCompensationSeparableConv(dwconv_layer, pointwiseconv_layer):
        # Convolution2D has weights in shape (outCH, inCH, fH, fW)
        # ConvolutionDepthwise2D has weights in shape (chMultiplier, inCH, fH, fW)

        dw_weights = dwconv_layer.getWeights().data
        pw_weights = pointwiseconv_layer.getWeights().data

        ch = dw_weights.shape[1]
        ch_mult = dw_weights.shape[0]
        dw_weights_extend_shape = (dw_weights.shape[0]*dw_weights.shape[1], dw_weights.shape[1],
                               dw_weights.shape[2], dw_weights.shape[3])
        dw_weights_extend = np.zeros(dw_weights_extend_shape)

        for c in range(ch):
            pad_l = c*ch_mult
            pad_r = (ch-c-1)*ch_mult
            npad = ((pad_l,pad_r), (0,0), (0,0))
            x = np.pad(dw_weights[:,c,:,:], npad, mode='constant', constant_values=(0, 0))
            dw_weights_extend[:,c,:,:] = x

        final_weights = np.matmul(dw_weights_extend.T, pw_weights.T[0][0]).T

        pointwiseconv_layer.setWeights(final_weights)
        pointwiseconv_layer.loadKernelSize(dwconv_layer.getKernelSize()[0], dwconv_layer.getKernelSize()[1])
        pointwiseconv_layer.loadStrideSize(dwconv_layer.getStrideSize()[0], dwconv_layer.getStrideSize()[1])
        pointwiseconv_layer.loadPadding(dwconv_layer.getPadding()[0], dwconv_layer.getPadding()[1])
        pointwiseconv_layer.padStyle = dwconv_layer.padStyle

        return pointwiseconv_layer

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isPointwiseConv, isDepthwiseConv, WeightCompensationSeparableConv, keep_node_a=False)

    return g


def fuseBiasAdd(g):
    from Controllers.Parsers.Parser.InnerProduct import InnerProduct
    from Controllers.Optimizer import fuse_nodes

    """
        Iterates over the graph removing any qualifying fusions for
        bias and add until we are complete.
    """

    def isBiasOrAdd(layer):
        """
            Returns True/False if the given layer is/is not a Bias or Add Layer
        """
        from Controllers.Parsers.Parser.Bias import Bias
        from Controllers.Parsers.Parser.Eltwise import Eltwise
        return (type(layer) == Bias) or \
                ((type(layer) == Eltwise) and (layer.getType() == Eltwise.Type.WSUM))

    def isConvOrFC(layer):
        """
            Returns True/False if the given layer is/is not a Convolution or InnerProduct Layer
        """
        from Controllers.Parsers.Parser.Convolution2D import Convolution2D, ConvolutionDepthWise2D
        return type(layer) in [Convolution2D, ConvolutionDepthWise2D, InnerProduct]

    def PutBiasInConv(layer, absorbed_layer):
        """
            To account for the removal of Bias and Add, we insert the bias
        """
        from Controllers.Parsers.Parser.Bias import Bias
        from Controllers.Parsers.Parser.Eltwise import Eltwise

        if (type(absorbed_layer) == Bias):
            b = absorbed_layer.getBias()
        else:
            # TODO: pull the data out of the Add input
            b = 0
            assert("TensorFlow: Add after Matmul is not supported")

        # Change Bias
        if layer.biasEnabled():
            if b is not None:
                layer.setBias(layer.getBias().data + b)
        else:
            # If there is no bias, it is possible that we will need to now have one
            if b is not None:
                layer.setBiasEnabled(True)
                layer.setBias(np.array(b).astype(np.float16))
        return layer

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isBiasOrAdd, isConvOrFC, PutBiasInConv)

    return g
