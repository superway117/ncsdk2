#!/usr/bin/env python3

# Copyright 2018 Intel Corporation.
# The source code, information and material ("Material") contained herein is
# owned by Intel Corporation or its suppliers or licensors, and title to such
# Material remains with Intel Corporation or its suppliers or licensors.
# The Material contains proprietary information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright laws and treaty
# provisions.
# No part of the Material may be used, copied, reproduced, modified, published,
# uploaded, posted, transmitted, distributed or disclosed in any way without
# Intel's prior express written permission. No license under any patent,
# copyright or other intellectual property rights in the Material is granted to
# or conferred upon you, either expressly, by implication, inducement, estoppel
# or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

from Controllers.Parsers.Parser.Pad import Pad
from Controllers.Parsers.TensorFlowParser.Helpers import getInputNames, getOutputNames, findTensorValue
from Models.EnumDeclarations import ErrorTable


def load(obj, operations):
    assert(len(obj.inputs) == 2)
    assert(len(obj.outputs) == 1)

    input = obj.inputs[0]

    pad_array = obj.inputs[1]
    pad_values = findTensorValue(pad_array.name, operations)

    if len(pad_values) != 4:
        throw_error(ErrorTable.InputSyntaxNotSupported, "Can only pad a 4-D tensor")
    elif (pad_values[0][0] != 0) or (pad_values[0][1] != 0):
        throw_error(ErrorTable.InputSyntaxNotSupported, "Cannot pad first dimension of the tensor")
    elif (pad_values[3][0] != 0) or (pad_values[3][1] != 0):
        throw_error(ErrorTable.InputSyntaxNotSupported, "Cannot pad the last dimension (depth) of the tensor")
    elif pad_values[1][0] != pad_values[1][1]:
        throw_error(ErrorTable.InputSyntaxNotSupported, "Cannot pad with different left/right values in dimension 1")
    elif pad_values[2][0] != pad_values[2][1]:
        throw_error(ErrorTable.InputSyntaxNotSupported, "Cannot pad with different left/right values in dimension 2")

    x = Pad(obj.name, [input.name], getOutputNames(obj))
    x.set_padding_size(pad_values[1][0], pad_values[1][1], pad_values[2][0], pad_values[2][1])

    return [x]
