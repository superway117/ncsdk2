#!/usr/bin/env python3

# Copyright 2018 Intel Corporation.
# The source code, information and material ("Material") contained herein is
# owned by Intel Corporation or its suppliers or licensors, and title to such
# Material remains with Intel Corporation or its suppliers or licensors.
# The Material contains proprietary information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright laws and treaty
# provisions.
# No part of the Material may be used, copied, reproduced, modified, published,
# uploaded, posted, transmitted, distributed or disclosed in any way without
# Intel's prior express written permission. No license under any patent,
# copyright or other intellectual property rights in the Material is granted to
# or conferred upon you, either expressly, by implication, inducement, estoppel
# or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

from Controllers.Parsers.Parser.Eltwise import Eltwise
from Controllers.Parsers.Parser.Scale import Scale
from Controllers.Parsers.Parser.Bias import Bias
from Controllers.Parsers.TensorFlowParser.Helpers import getInputNames, getOutputNames, findTensorValue
import numpy as np

from Controllers.EnumController import throw_error, ErrorTable, compiler_assert

def load(obj, operations):
    # have at least two inputs

    compiler_assert(len(obj.inputs) == 2, ErrorTable.StageDetailsNotSupported, obj.name)
    compiler_assert(len(obj.outputs) == 1, ErrorTable.StageDetailsNotSupported, obj.name)
    
    input1 = obj.inputs[0]
    input2 = obj.inputs[1]
    output = obj.outputs[0]

    compiler_assert(any(len(x) == 4 for x in [input1.get_shape(), input2.get_shape()]),
                    ErrorTable.StageDetailsNotSupported, obj.name)

    # at this point, we know that at least one input tensor has 4 axes
    # if input1 has less than 4 axes, swap inputs, such that input1 is the one with 4 axes
    if (len(input1.get_shape()) < 4):
        input1, input2 = input2, input1

    if len(input2.get_shape()) <= 1:
        if (obj.type == 'Mul'):
            x = Scale(obj.name, [input1.name], [output.name])
        
            scales = findTensorValue(input2.name, operations)
            # broadcast scales value to a 1-dim array of size input1.channels
            # the broadcast will fail if scales size is not 1 or input1.channels
            scales = np.broadcast_to(scales, input1.get_shape()[3])
            x.assignMultiplier(scales)
        elif (obj.type == 'Add' or obj.type == 'Sub' ):
            x = Bias(obj.name, [input1.name], [output.name])
        
            bias = findTensorValue(input2.name, operations)
            bias = np.broadcast_to(bias, input1.get_shape()[3])
            if (obj.type == 'Sub'):
                bias = -1.0 * bias
            x.loadBias(bias)
        else:
            throw_error(ErrorTable.StageDetailsNotSupported, obj.name)
    elif len(input1.get_shape()) == 4 and len(input2.get_shape()) == 4:
        x = Eltwise(obj.name, getInputNames(obj), getOutputNames(obj))

        eltwise_type = {
            'Add': Eltwise.Type.WSUM,
            'Sub': Eltwise.Type.WSUM,
            'Mul': Eltwise.Type.WPROD,
            'Maximum': Eltwise.Type.WMAX
        }.get(obj.type, False)

        compiler_assert(eltwise_type, ErrorTable.StageDetailsNotSupported, obj.name)

        x.loadType(eltwise_type)
    else:
        throw_error(ErrorTable.StageDetailsNotSupported, obj.name)

    return [x]