#!/usr/bin/env python3

# Copyright 2018 Intel Corporation.
# The source code, information and material ("Material") contained herein is
# owned by Intel Corporation or its suppliers or licensors, and title to such
# Material remains with Intel Corporation or its suppliers or licensors.
# The Material contains proprietary information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright laws and treaty
# provisions.
# No part of the Material may be used, copied, reproduced, modified, published,
# uploaded, posted, transmitted, distributed or disclosed in any way without
# Intel's prior express written permission. No license under any patent,
# copyright or other intellectual property rights in the Material is granted to
# or conferred upon you, either expressly, by implication, inducement, estoppel
# or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.


from Controllers.Parsers.Parser.InnerProduct import InnerProduct
from Controllers.Parsers.TensorFlowParser.Helpers import getInputNames, getOutputNames, findTensorValue
import numpy as np

def load(obj, operations):
    assert(len(obj.inputs) == 2)
    assert(len(obj.outputs) == 1)

    # first input always assumed to be MatMul input
    # the second input is the weights tensor
    inputs = [getInputNames(obj)[0]]
    outputs = [getOutputNames(obj)[0]]

    x = InnerProduct(obj.name, inputs, outputs)

    x.setBiasEnabled(False) # do not have a bias here

    # Load weights parameters; assumed to be the second input tensor
    kernel = obj.inputs[1]
    weightName = kernel.name
    weights = findTensorValue(weightName, operations)
    weights = np.transpose(weights, (1, 0))

    x.loadTrainedParameters(weights=weights, bias=None)

    return [x]