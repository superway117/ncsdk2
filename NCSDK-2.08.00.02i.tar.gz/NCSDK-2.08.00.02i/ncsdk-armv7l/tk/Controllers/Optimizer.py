# Copyright 2018 Intel Corporation.
# The source code, information and material ("Material") contained herein is
# owned by Intel Corporation or its suppliers or licensors, and title to such
# Material remains with Intel Corporation or its suppliers or licensors.
# The Material contains proprietary information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright laws and treaty
# provisions.
# No part of the Material may be used, copied, reproduced, modified, published,
# uploaded, posted, transmitted, distributed or disclosed in any way without
# Intel's prior express written permission. No license under any patent,
# copyright or other intellectual property rights in the Material is granted to
# or conferred upon you, either expressly, by implication, inducement, estoppel
# or otherwise.
# Any license under such intellectual property rights must be express and
# approved by Intel in writing.

import os
import sys
import numpy as np
from Models.Network import *
from Models.NetworkStage import *
from Models.MyriadParam import *
from Models.EnumDeclarations import *
from Controllers.EnumController import throw_error
import networkx as nx
from Controllers.Parsers.Parser.Conversion import Conversion
from Controllers.Parsers.Parser.Concat import Concat
from Controllers.Parsers.Parser.Convolution2D import Convolution2D, Deconvolution, ConvolutionDepthWise2D
from Controllers.Parsers.Parser.Pooling import Pooling
from Controllers.Parsers.Parser.InnerProduct import InnerProduct
from Controllers.Parsers.Parser.Permute import Permute, PermuteFlatten
from Controllers.Parsers.Parser.ReLU import ReLU, LeakyReLU
from Controllers.Parsers.Parser.Input import Input
from Controllers.Parsers.Parser.Output import Output
from Controllers.Parsers.Parser.Eltwise import Eltwise
from Controllers.Parsers.Parser.crop import Crop
from Controllers.Parsers.Parser.Hw import HwOp, HwConvolution, HwConvolutionPooling, HwFC, HwPooling
from Controllers.Parsers.Parser.Bias import Bias
from Controllers.Parsers.Parser.Scale import Scale

import Controllers.Globals as GLOBALS
from Controllers.Tensor import UnpopulatedTensor, Tensor
from Controllers.Adaptor import convertLayouttoStorageEnum
from Controllers.CnnHardware import hardwareize
from Views.IRVisualize import drawIRNetworkX, drawIR, drawGraph
from Controllers.ConversionPlacement import fixTensors as fixTensorImported
from Controllers.Parsers.Parser.NoOp import NoOp, Identity
from Controllers.Parsers.Parser.Layer import MangledName, OriginalName

import Models.Layouts as Layouts

from Controllers.GraphUtils import buildGraph, buildLayerLists

def postParsingOptimizations(parsedLayers):
    # Build optimization graph
    g = buildGraph(parsedLayers)

    """
        Fuse Pad->Convolution2D sequences, by absorbing Pad into Convolution2D
    """
    print("Fusing Pad and Convolution2D")
    g = fusePadConvolution2D(g)

    """
        Removes Add or Batch layers by absorbing them into leading Convolutions
    """

    """
        Removes BatchNorm and Scale layers by absorbing them into leading Convolutions
    """
    print("Fusing BatchNorm and Scale after Convolution")
    g = fuseBatchNormScale(g)


    """
        Removes BatchNorm layers, and replaces them with Bias&Scale (after the assumption that
        all BN that could be fused into Conv's, were)
    """
    print("Replacing BN with Bias&Scale")
    g = replaceBatchNorm(g)


    """
        Fuse Permute->Flatten sequences, by absorbing Flatten into Permute
    """
    print("Fusing Permute and Flatten")
    g = fusePermuteFlatten(g)

    """
        Fuse Eltwise->Relu sequences, by absorbing Relu into Eltwise
    """
    print("Fusing Eltwise and Relu")
    g = fuseEltwiseRelu(g)

    """
        Eliminate layers that have been parsed as NoOp (e.g. Dropout)
    """
    print("Eliminate layers that have been parsed as NoOp")
    g = eliminateNoOps(g)


    return buildLayerLists(g)

def selectImplementations(parsedLayers, scheduler, myriadX, bypass_opt=False):
    '''
    Perform several optimization pass to the parsedLayers list
    :param: list of parsed layers from CaffeParser
    :return: TBD
    '''
    # Build optimization graph
    g = buildGraph(parsedLayers)

    if myriadX:
        # Decide about the implementation of each layer
        # print("Replace element-wise sum operations with concats and convolutions")
        # g = eltWiseSumAsConv(g, scheduler)
        print("Hw layers implementation")
        g = deconvolution_as_convolution(g, scheduler)
        g = depthwise_conv_as_group_conv(g, scheduler)
        g = split_group_convolution(g, scheduler)
        g = implementHwOps(g, scheduler, bypass_opt)

    """
    SW layers integration: At this stage, the input and output layers will be configured, such that:
       1) they are compatible with the hw layers,
       2) no consideration to whether the layer is HW-friendly of not,
       3) the tensors between two sw layer will follow Channel-Minor format,
       4) Concat is not be regarded as sw nor hw layer, which means its inputs/outputs will follow layout of layers connected to it.
    """
    # print("SW layer integration")
    # g = swIntegration(g, myriadX)

    """
    SW layers adaptation: At this pass data layout conversion layers will be inserted in the following situations:
       1) before and/or an hw-unfriendly sw layer if its input and/or output is in hw layout,
       2) applied to an input of a concat to adapt it to preferred input/output layout.
    Furthermore, Copy layer added to the output of a concat which an input to another layer which doesn’t support the stride of the concat output.
    """
    # print("SW layer adaptation")
    # g = swAdaptation(g, )

    if myriadX:
        print("Stream-everything scheduling")
        streamEverythingSchedule(g, scheduler, bypass_opt)

    return buildLayerLists(g)

def streamEverythingSchedule(g, scheduler, bypass_opt=False):
    opt_graph = g.copy()
    opt_graph = optimizeSubgraphs(opt_graph, scheduler)
    optimizeBranches(opt_graph, scheduler)

    # Apply data location
    for stageName in g.node:
        node = g.node[stageName]['ref']
        if isHWLayer(node):
            node.setImplementation(scheduler, bypass_opt)

def fixTensors(parsedLayers, scheduler, myriadX):
    return fixTensorImported(parsedLayers, scheduler, myriadX)


def eliminateNoOps(g):
    """
        Iterates over the graph removing NoOps
    """

    def isNoOp(layer):
        """
            Layers such as Dropout is considered a NoOp for inference
        """
        from Controllers.Parsers.Parser.NoOp import NoOp
        return type(layer) == NoOp

    def noCompensation(layer, absorbed_layer):
        return layer

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isNoOp, lambda layer: True, noCompensation, failure_allowed=True)
    return g

def replaceBatchNorm(g):
    """
        Itrerates over all layers, and changes the BatchNorm type layers into simple
        Scale layers. This phase should be used, after Conv/Pad + BatchNorm fusions.
        Then, since for example Caffe, permits to have a Scale layer after BatchNorm
        we want to fuse the now converted Scale layer with the original one.
    """

    def isBatchNorm(layer):
        from Controllers.Parsers.Parser.BatchNorm import BatchNorm
        return type(layer) in [BatchNorm]

    def isScale(layer):
        from Controllers.Parsers.Parser.Scale import Scale
        return type(layer) in [Scale]

    def WeightCompensationBatchNormToScale(layer, absorbed_layer):
        """
            Fields from BatchNorm layer to Scale layer. A sort-of dummy op,
            since the 2 are the same, but the obj type is different, and we want to
            keep logic consistency.
        """
        from Controllers.Parsers.Parser.BatchNorm import BatchNorm
        from Controllers.Parsers.Parser.Scale import Scale

        b = absorbed_layer.getBiasBeta()
        w = absorbed_layer.getMultiplier()

        layer.assignBiasBeta(b)
        layer.assignMultiplier(w)

        return layer

    def WeightCompensationScaleToScale(layer, absorbed_layer):
        from Controllers.Parsers.Parser.Scale import Scale

        """
            Fuse 2 Scale type layers.
        """
        parent_mult = layer.getMultiplier()
        parent_bias = layer.getBiasBeta()

        child_mult = absorbed_layer.getMultiplier()
        child_bias = absorbed_layer.getBiasBeta()

        w = parent_mult * child_mult
        b = child_mult * parent_bias + child_bias

        layer.assignBiasBeta(b)
        layer.assignMultiplier(w)

        return layer

    for node in nx.lexicographical_topological_sort(g):
        if isBatchNorm(g.node[node]['ref']):

            new_scale_name = g.node[node]['ref'].name.stringifyOriginalName()

            predecessors = list(g.predecessors(node))

            #TODO: error? BatchNorm should not really have more than one parent
            if(len(predecessors) != 1):
                continue

            parent = predecessors[0]

            addLayerInBetween(g,parent,node,Scale,new_scale_name,False)

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isBatchNorm, isScale, WeightCompensationBatchNormToScale)

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isScale, isScale, WeightCompensationScaleToScale)

    return g

def fuseBatchNormScale(g):
    """
        Iterates over the graph removing any qualifying fusions for
        scale and batchnorm until we are complete.
    """
    def isBatchNormOrScale(layer):
        """
            Returns True/False if the given layer is/is not a BatchNorm or Scale Layer
        """
        from Controllers.Parsers.Parser.BatchNorm import BatchNorm
        from Controllers.Parsers.Parser.Scale import Scale
        return type(layer) in [BatchNorm, Scale]


    def isConv(layer):
        """
            Returns True/False if the given layer is/is not a Convolution Layer
        """
        from Controllers.Parsers.Parser.Convolution2D import Convolution2D, ConvolutionDepthWise2D
        return type(layer) in [Convolution2D, ConvolutionDepthWise2D]

    def WeightCompensationBNScale(layer, absorbed_layer):
        """
            To account for the removal of Batch Norm and scale, we adjust the weights
            and bias accordingly.
            See https://github.com/zhang-xin/CNN-Conv-BatchNorm-fusion for reference.
        """
        from Controllers.Parsers.Parser.BatchNorm import BatchNorm

        b = absorbed_layer.getBiasBeta()
        w = absorbed_layer.getMultiplier()

        # For Convolution2D the weights shape is [outCH, inCH, fH, fW]
        # For ConvolutionDepthwise2D the weights shape is [chMultiplier, inCH, fH, fW]
        if type(layer) in [ConvolutionDepthWise2D]:
            conv_w_shape = layer.getWeights().data.shape
            w = w.reshape((conv_w_shape[1], conv_w_shape[0]))

        # Change Weights
        layer.setWeights((layer.getWeights().data.T * w).T)   # Transpose in order to be able to use dimension broadcasting

        # Change Bias
        if layer.biasEnabled():
            if b is not None:
                layer.setBias(layer.getBias().data * w + b)
            else:
                layer.setBias(layer.getBias().data * w)
        else:
            # If there is no bias, it is possible that we will need to now have one
            if b is not None:
                layer.setBiasEnabled(True)
                layer.setBias(np.array(b).astype(np.float16))

        return layer

    check_again = True
    while check_again:
        # Failure not allowed (default not allowed) because we have no myiad implementation of Batchnorm.
        g, check_again = fuse_nodes(g, isBatchNormOrScale, isConv, WeightCompensationBNScale)

    return g

def fusePermuteFlatten(g):
    """
        Iterates over the graph removing any qualifying fusions for
        Flatten until we are complete.
    """
    import operator

    def isPermute(layer):
        """
            Returns True/False if the given layer is/is not a Permute Layer
        """
        from Controllers.Parsers.Parser.Permute import Permute
        return type(layer) in [Permute]


    def isFusibleFlatten(layer):
        """
            Returns True/False if the given layer is/is not a Flatten Layer
        """
        from Controllers.Parsers.Parser.Flatten import Flatten
        fusible_flatten = type(layer) in [Flatten] and layer.axis == 1 and \
                        layer.end_axis in [-1, 3, None]
        return fusible_flatten


    def FusePermuteFlatten(layer, absorbed_layer):
        fused_layer = PermuteFlatten(layer)
        new_name = 'FUSED_' + layer.name.stringifyOriginalName() + '_' + \
                   absorbed_layer.name.stringifyOriginalName()
        mangled_name = MangledName(OriginalName(new_name))
        fused_layer.setName(mangled_name)
        return fused_layer

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isFusibleFlatten, isPermute, FusePermuteFlatten, failure_allowed=True)

    return g


def fuseEltwiseRelu(g):
    """
        Iterates over the graph removing any qualifying fusions for
        Relu until we are complete.
    """
    import operator

    def isEltwise(layer):
        """
            Returns True/False if the given layer is/is not a Eltwise Layer
        """
        from Controllers.Parsers.Parser.Eltwise import Eltwise
        return type(layer) in [Eltwise]


    def isRelu(layer):
        """
            Returns True/False if the given layer is/is not a Relu Layer
        """
        return type(layer) in [ReLU]


    def EltwiseReluCompensation(eltwise_layer, relu_layer):
        eltwise_layer.hasInplaceReLU = True
        eltwise_layer.reLUnegSlope = relu_layer.negativeSlope
        return eltwise_layer

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isRelu, isEltwise, EltwiseReluCompensation)

    return g


def fusePadConvolution2D(g):
    """
        Iterates over the graph removing any qualifying fusions for
        Relu until we are complete.
    """
    import operator

    def isPad(layer):
        """
            Returns True/False if the given layer is/is not a Pad Layer
        """
        from Controllers.Parsers.Parser.Pad import Pad
        return type(layer) in [Pad]

    def isConvolution2D(layer):
        """
            Returns True/False if the given layer is/is not a Relu Layer
        """
        return type(layer) in [Convolution2D]


    def PadConvolution2dCompensation(pad_layer, convolution2d_layer):
        convolution2d_layer.setPadStyle('CAFFE')
        convolution2d_layer.loadPadding(pad_layer.get_padding_size()[0], pad_layer.get_padding_size()[1])
        return convolution2d_layer

    check_again = True
    while check_again:
        g, check_again = fuse_nodes(g, isConvolution2D, isPad, PadConvolution2dCompensation, keep_node_a=False)

    return g

def findClosestChild(g, source, children):
    """
    As this is a directed graph, we only get paths that move 'downwards'.
    If an equally distant child is found, returns the last discovered entry
    """

    source_name = source.name.stringifyName()

    shortest = None
    shortest_child = None
    for child in children:
        child_name = child.name.stringifyName()
        # Search for children
        try:
            path = nx.shortest_path(g, source=source_name, target=child_name)
        except nx.exception.NetworkXNoPath:
            path = None

        # Check if shorter than before
        if shortest is None:
            shortest = path
            shortest_child = child
        elif path is not None and len(path) <= len(shortest):
            shortest = path
            shortest_child = child

    return shortest_child


def fuse_nodes(g, test_for_node_b, test_for_node_a, compensation_function, failure_allowed=False, keep_node_a=True):
    """
        A generic function to fuse nodes together.

        We 'fuse' two layers together by absorbing one into the other

        Parameters:
        @g - graph object from networkx.
        @test_for_node_a - condition to match for node 'A' in above example
        @test_for_node_b - condition to match for node 'B' in above example
        @compensation_function - once the fuse has been identified, perform this user-provided function to account for
            the loss of this layer.
        @failure_allowed - If set to true, a failed fusion will be cancelled (returning -1, -1).
        @keep_node_a - If true, A -> B becomes A; if false, A -> B becomes B
            If remained as false, a fatal error will trigger.
    """

    contraction_list = []


    # print('Before fusion')
    # for stageName in g.node:
    #     print(stageName, g.node[stageName]['ref'].getStringifiedName(), g.node[stageName]['type'])

    # print('postParsingOptimizations')
    # for stageName in buildGraph(buildLayerLists(g)).node:
    #     print('>>>', stageName, g.node[stageName]['ref'].getStringifiedName(), g.node[stageName]['type'])
    #     for inputNodes in g.node[stageName]['ref'].getInputTensorNames():
    #         print(inputNodes.stringifyName())

    # TODO: Check that the output of concrete node goes only to the fusing node,
    # otherwise we have a logical error.

    # Any qualifying fusions are identified here.
    for n in g.node:
        if test_for_node_a(g.node[n]['ref']):
            for succ in g.successors(n):
                if test_for_node_b(g.node[succ]['ref']):
                    contraction_list.append((n, succ))

    # Fuse and Remove
    for a, b in contraction_list:
        node_a_ref = g.node[a]['ref']
        node_a = g.node[a]
        node_b_ref = g.node[b]['ref']
        node_b = g.node[b]

        if len(list(g.successors(a))) > 1:
            if failure_allowed:
                return -1, -1
            else:
                throw_error(ErrorTable.GraphConstructionFailure, "Fusing into a layer with multiple successors is not supported: ("+n+")")

        # TODO: Compensation.

        if keep_node_a:

            node_a_ref = compensation_function(node_a_ref, node_b_ref)
            g = nx.contracted_edge(g, (a, b), self_loops=False)

            node_a_ref.setOutputTensors(node_b_ref.getOutputTensors())
            node_a_ref.setOutputTensorNames(node_b_ref.getOutputTensorNames())
            node_a_ref.loadOutputTensorSizes([t.getShape() for t in node_b_ref.getOutputTensors()])
            g.node[a]['ref'] = node_a_ref
            g.node[a].pop('contraction', None)

        else:

            node_b_ref = compensation_function(node_a_ref, node_b_ref)
            node_b_ref.setInputTensors(node_a_ref.getInputTensors())
            node_b_ref.setInputTensorNames(node_a_ref.getInputTensorNames())
            node_b_ref.loadInputTensorSizes([t.getShape() for t in node_a_ref.getInputTensors()])

            # contracted_edge can only merge successor into the predecessor, therefore we tricked it by
            #   copying the ref content of b into a before contracting the edge

            g.node[a]['ref'] = node_b_ref
            g = nx.contracted_edge(g, (a, b), self_loops=False)
            g.node[a].pop('contraction', None)

    return g, len(contraction_list) > 0


def eltWiseSumAsConv(g, scheduler):
    '''
    Replace hardwareizable Element Wise sum in concat + conv
    the two input blobs are concatenated together (implicitly) and then summed elementwise
    using an appropriate 1x1 convolutional kernel
    '''
    replace_lst = []
    for name in g.node:
        layer = g.node[name]['ref']
        if isinstance(layer, Eltwise):
            eltwise_conv, eltwise_concat = layer.convert2Conv()
            if layer.getType() == Eltwise.Type.WSUM and HwConvolution.isHardwarizeable(eltwise_conv, scheduler):
                replace_lst.append((name, (eltwise_conv, eltwise_concat)))

    for name, (eltwise_conv, eltwise_concat) in replace_lst:
        pred_list = list(g.predecessors(name))
        succ_list = list(g.successors(name))
        g.remove_node(name)
        # Add nodes
        g.add_node(eltwise_concat.name.stringifyName(),type="OP", ref=eltwise_concat)
        g.add_node(eltwise_conv.name.stringifyName(),type="OP", ref=eltwise_conv)
        # Add edges
        g.add_edge(eltwise_concat.name.stringifyName(), eltwise_conv.name.stringifyName())
        for pred in pred_list:
            g.add_edge(pred, eltwise_concat.name.stringifyName())
        for succ in succ_list:
            g.add_edge(eltwise_conv.name.stringifyName(), succ)

    return g

def isFirstorLast(g, name):
    first = any([isinstance(g.node[pred]['ref'], Input) for pred in g.predecessors(name)])
    last = any([isinstance(g.node[succ]['ref'], Output) for succ in g.successors(name)])
    return first or last

def depthwise_conv_as_group_conv(g, scheduler):

    for name in g.node:
        layer = g.node[name]['ref']
        if isinstance(layer, ConvolutionDepthWise2D) and not isFirstorLast(g,name):
            g.node[name]['ref'] = layer.convert2GroupConv(scheduler)

    return g

def split_group_convolution(g, scheduler):

    replace_lst = []
    for name in g.node:
        layer = g.node[name]['ref']
        if isinstance(layer, Convolution2D) and layer.groupSize > 1 and not isFirstorLast(g,name):
            replacement_layers = layer.genGroupConvs()
            if all([HwConvolution.isHardwarizeable(l, scheduler) for l, c in replacement_layers]):
                replace_lst.append((name, replacement_layers))

    for name, replacement_layers in replace_lst:
        # add slice and concat
        pred = list(g.predecessors(name))
        succ = list(g.successors(name))
        assert(len(pred)==1)

        for l, c in replacement_layers:

            # Build the graph
            g.add_node(l.name.stringifyName(), type='OP', ref=l)
            g.add_node(c.name.stringifyName(), type='OP', ref=c)
            g.add_edge(c.name.stringifyName(), l.name.stringifyName())

            for p in pred:
                g.add_edge(p, c.name.stringifyName())


        conc = Concat("concat_" + g.node[name]['ref'].name.stringifyName(), [], [])
        conc.setInputTensorsAllFields([l.getOutputTensors()[0] for l, c in replacement_layers])
        conc.setOutputTensorsAllFields(g.node[name]['ref'].getOutputTensors())
        conc.loadConcatAxis(1)
        #Remove channel minor from available tensor layout
        conc.formatPool = [formatPool for formatPool in conc.formatPool if formatPool[0].layout != Layouts.NHWC]

        g.add_node(conc.name.stringifyName(), type='OP', ref=conc)

        for l, c in replacement_layers:
            g.add_edge(l.name.stringifyName(), conc.name.stringifyName())

        for s in succ:
            g.add_edge(conc.name.stringifyName(), s)

        g.remove_node(name)

    return g

def deconvolution_as_convolution(g, scheduler):
    '''
    Replaces a Deconvolution layer with:
        1. If the the kernel stride are all equal to 1 and the width pad size and
        height pad size are equal to width / 2 and respectively height / 2 the
        Deconvolution layer is replaced with a Convolution layer if this equvialent
        layer can be executed on the CNN hardware block.
        2. If the condtion at point 1 does not hold true than the Deconvolution layer
        is replaced with an Upsampling layer coupled with a Convolution layer if
        the convolution layer can be executed on the CNN hardware block.
        3. If neither 1 nor 2 hold true than the Deconvolution layer is not replaced.
    '''

    replace_lst = []
    for name in g.node:
        layer = g.node[name]['ref']
        if isinstance(layer, Deconvolution):
            replacement_layers = layer.convert2Conv()
            if HwConvolution.isHardwarizeable(replacement_layers["conv"], scheduler):
                replace_lst.append((name, replacement_layers))

    for name, replacement_layers in replace_lst:
        pred_list = list(g.predecessors(name))
        succ_list = list(g.successors(name))
        g.remove_node(name)

        g.add_node(replacement_layers["conv"].name.stringifyName(),
                   type="OP", ref=replacement_layers["conv"])

        if (replacement_layers["upsampling"] is not None):
            g.add_node(replacement_layers["upsampling"].name.stringifyName(),
                       type="OP", ref=replacement_layers["upsampling"])

        g.add_edge(replacement_layers["upsampling"].name.stringifyName(),
                   replacement_layers["conv"].name.stringifyName())

        for pred in pred_list:
            if (replacement_layers["upsampling"] is not None):
                g.add_edge(pred, replacement_layers["upsampling"].name.stringifyName())
            else:
                g.add_edge(pred, replacement_layers["conv"].name.stringifyName())
        for succ in succ_list:
            g.add_edge(replacement_layers["conv"].name.stringifyName(), succ)

    return g

def implementHwOps(g, scheduler, bypass_opt = False):
    # Pass 1: decide if layer is hw or sw
    for name in g.node:
        layer = g.node[name]['ref']
        # TODO: Shorten this code.
        if isinstance(layer, Convolution2D):
            # check if really layer can be implemented in hw
            if HwConvolution.isHardwarizeable(layer, scheduler):
                hw_layer = HwConvolution(layer)
                # Only for solution and splits
                hw_layer.setImplementation(scheduler, True)
                if bypass_opt:
                    hw_layer.compatible_layouts = [Layouts.NHCW]
                g.node[name]['ref'] = hw_layer

        if isinstance(layer, Pooling):
            # check if really layer can be implemented in hw
            if HwPooling.isHardwarizeable(layer, scheduler):
                hw_layer = HwPooling(layer)
                if bypass_opt:
                    hw_layer.compatible_layouts = [Layouts.NHCW]
                g.node[name]['ref'] = hw_layer

        if isinstance(layer, InnerProduct):
            # check if really layer can be implemented in hw
            if HwFC.isHardwarizeable(layer, scheduler):
                hw_layer = HwFC(layer)
                if bypass_opt:
                    hw_layer.compatible_layouts = [Layouts.NHCW]
                g.node[name]['ref'] = hw_layer
            elif layer.canBeConvolution():
                conv_layer = layer.convert2Conv()
                if HwConvolution.isHardwarizeable(conv_layer, scheduler):
                    print('FC layer {} converted as convolution!'.format(conv_layer.getStringifiedName()))
                    hw_layer = HwConvolution(conv_layer)
                    # Only for solution and splits
                    hw_layer.setImplementation(scheduler, True)
                    if bypass_opt:
                        hw_layer.compatible_layouts = [Layouts.NHCW]
                    g.node[name]['ref'] = hw_layer

    # Pass 2: Bring inside subgraphs relevant operation
    g =  insertOpsIntoSubgraphs(g)

    # Pass 3: fusing inPlace ops (Prelu, Relu, Scale, Bias etc...)
    check_again = True
    while check_again:
        g, check_again = contractHwOp(g, isInPlace)

    # Pass 4: fusing hw related op (like convolutions and non overlapping pooling)
    g, _ = contractHwOp(g, isNonOvlPooling)

    # return a clean graph
    return g

def hwScheduling(g, scheduler, bypass_opt = False, verbose = False):
    '''
    Idea: optimize every branch of Hw layers of the network independently
    1) optimize subgraphs
    2) optimize individual branches
    '''
    opt_graph = g.copy()
    opt_graph = optimizeSubgraphs(opt_graph,scheduler)
    optimizeBranches(opt_graph, scheduler)

    # ApplyAdapt shapes
    for stageName in g.node:
        node = g.node[stageName]['ref']
        if isHWLayer(node):
            node.setImplementation(scheduler, bypass_opt)
            in_ch, out_ch, _ = node.getSolution()
            splits = node.getSplitOverC()
            if isinstance(node, HwConvolution):
                in_ch *= splits
            for tensor in node.inputTensors:
                tensor.proposeShape((tensor.shape[0], in_ch, tensor.shape[2], ((tensor.shape[3] + 7)//8)*8))

            for tensor in node.outputTensors:
                tensor.proposeShape((tensor.shape[0], out_ch, tensor.shape[2], ((tensor.shape[3] + 7)//8)*8))


    for stageName in g.node:
        if isHWLayer(g.node[stageName]['ref']):
            g.node[stageName]['ref'].adaptTensors()

    if verbose:
        print('************************************************')
        for stageName in  g.node:
            try:
                print(stageName, scheduler.ordered_dict[stageName])
            except Exception as e:
                pass
        print('************************************************')

def swIntegration(g, myriadX, verbose = False):

    # TODO: Naive approach, change
    # Preference order: interleaved, planar, channel minor
    if myriadX:
        preference_layouts = [Layouts.NHCW, Layouts.NCHW, Layouts.NHWC]
    else:
        preference_layouts = [Layouts.NHWC]
    for name in nx.lexicographical_topological_sort(g):
        layer = g.node[name]['ref']
        if layer.getInputTensorsCount() < 2:
            for layout in preference_layouts:
                # if isinstance(layer, Input):
                #     if layout in g.node[g.successors(name)[0]]['ref'].compatible_layouts:
                #         break
                # else:
                    if layout in layer.compatible_layouts:
                        break
            for outputTensor in layer.outputTensors:
                print("Set layout of {}: {}".format(outputTensor.name, layout))
                outputTensor.setLayout(layout)
        else:
            in_layouts = [x.getLayout() for x in layer.inputTensors]

            if len(set(in_layouts)) != 1:
                # Minimize the number of eventual conversion layer
                layout = max(in_layouts,key=in_layouts.count)
            else:
                layout = in_layouts[0]

            layer.compatible_layouts = [layout]
            for outputTensor in layer.outputTensors:
                outputTensor.setLayout(layout)

    return g

def swAdaptation(g, verbose = False):
    for child in nx.lexicographical_topological_sort(g):
        layer = g.node[child]['ref']
        for inputTensor, inputTensorName in zip(layer.inputTensors, layer.inputTensorNames):
            if not inputTensor.getLayout() in [x for x in layer.compatible_layouts]:
                # remove previous edge and add connection in and from
                predecessors = list(g.predecessors(child))
                for parent in predecessors:
                    if inputTensorName in g.node[parent]['ref'].outputTensorNames:
                        print("Add a conversion layer for tensor {}".format(inputTensorName))
                        new_layer_name = '{}_converted'.format(child)
                        addLayerInBetween(g, parent, child, Convert, new_layer_name)
                        g.node[new_layer_name]['ref'].setLayouts(inputTensor.getLayout(), layer.inputTensors[0].getLayout())

    return g

# TODO: remove legacy code, reimplement with networkx
def optimizeSubgraphs(g, scheduler):
    '''
    Optimize each subgraph and then contract edges
    '''
    sorted_layers = list(nx.lexicographical_topological_sort(g))
    subgraphs = extractSubgraphs(g)
    for subgraph, subgraph_start, subgraph_end in subgraphs:
        net = genOptNetwork(subgraph)
        # find last element of subgraph (if subgraph in CMX, the one that need CMX unload)
        last_elem = list(filter(lambda x: get_null_terminating_name(x.name) == sorted_layers[sorted_layers.index(subgraph_end) - 1], net.stageslist))
        scheduler.process_subgraph(net.stageslist,net, 0, net.stageslist.index(last_elem[0])+1, 'D')

        g = contractSubgraph(g, subgraph_start, subgraph_end, subgraph)

    return g

def optimizeBranches(g,scheduler):

    branches = extractBranches(g)

    print("Found {} branches".format(len(branches)))
    for idx, branch in enumerate(branches):
        sg = g.subgraph(branch)
        print('\t[{}]: {}'.format(idx, list(nx.lexicographical_topological_sort(sg))))
        net = genOptNetwork(sg)
        scheduler.process_branch(net.stageslist, initial_config = 'D', final_config = 'D')

def insertOpsIntoSubgraphs(g):
    '''
    Pull relevant operations inside an hw subgraph
    A relevant example is hw group convolution implemented as cropped + conv + concat
    in the case of group_conv + (L/P)ReLU, it is necessary to pull the relu operation
    inside the concat in order to compile correctly
    '''
    nodelists = [n for n in g.node if isinstance(g.node[n]['ref'], Concat)]
    for n in nodelists:
            layer = g.node[n]['ref']
            pred_lst = list(g.predecessors(n))
            if len(list(g.successors(n))) == 1 and all([g.node[name]['ref'].isHW for name in pred_lst]) \
                    and g.node[list(g.successors(n))[0]]['ref'].inPlace:

                # Remove previous implace operation
                inplace = g.node[list(g.successors(n))[0]]['ref']
                inplace_succ = list(g.successors(list(g.successors(n))[0]))

                for hw in pred_lst:
                    l = g.node[hw]['ref']

                    # Push new implace operation inside the concat
                    new_inplace = type(inplace)(inplace.name.stringifyOriginalName(), [], [])
                    new_inplace.loadReluX(inplace.reluX)
                    new_inplace.loadNegativeSlope(inplace.negativeSlope)

                    # Create a new tensor
                    new_tensor = UnpopulatedTensor(inplace.getInputTensors()[0].shape)
                    new_tensor.setName(MangledName(OriginalName(inplace.getInputTensors()[0].name.stringifyName())))

                    # Setup input and output tensor
                    new_inplace.setInputTensorsAllFields([new_tensor])
                    new_inplace.setOutputTensorsAllFields(l.getOutputTensors())

                    # Set the output tensor of Hw operation to the input of the implace
                    l.setOutputTensorsAllFields(new_inplace.getInputTensors())

                    # Remove old connection
                    g.remove_edge(hw, n)
                    # Add the new implace node
                    g.add_node(new_inplace.name.stringifyName(), type='OP', ref=new_inplace)
                    g.add_edge(hw, new_inplace.name.stringifyName())
                    g.add_edge(new_inplace.name.stringifyName(), n)

                # Set concat tensor and edges
                layer.setOutputTensorsAllFields(inplace.getOutputTensors())
                g.remove_node(inplace.name.stringifyName())
                for succ in inplace_succ:
                    g.add_edge(n, succ)

    return g

# TODO: add support for PreOp
def contractHwOp(g, test):
    contraction_list = []
    # Contract the blob into the operation
    for n in g.node:
        if isinstance(g.node[n]['ref'], HwConvolution) or (isinstance(g.node[n]['ref'], HwFC) and test == isInPlace):
            for succ in g.successors(n):
                if test(g.node[succ]['ref']):
                    contraction_list.append((n,succ))

    # Contract PostOp
    for n,succ in contraction_list:
        old_layer = g.node[succ]['ref']
        if isNonOvlPooling(old_layer):
            # Can fuse only if split over c is == 1
            if HwConvolutionPooling.canFuse(conv = g.node[n]['ref'], pool = g.node[succ]['ref']):
                print("Fusing convolution {} with non overlapping pooling {}".format(n,succ))
                g.node[n]['ref'] = HwConvolutionPooling(g.node[n]['ref'])
                g.node[n]['ref'].setPoolingParameter(old_layer)
            else:
                continue
        else:
            print("Fusing {} with {}".format(n, succ))
            g.node[n]['ref'].setPostOp(old_layer)

        # Set the output of n to be equal to the output of old_layer
        g.node[n]['ref'].setOutputTensors(old_layer.getOutputTensors())
        g.node[n]['ref'].setOutputTensorNames(old_layer.getOutputTensorNames())
        g.node[n]['ref'].loadOutputTensorSizes([t.getShape() for t in old_layer.getOutputTensors()])

        # # Adjust tensors
        # for tensor in set.intersection(set(g.node[n]['ref'].outputTensors), set(g.node[succ]['ref'].inputTensors)):
        #     out_tensor_idx  = g.node[n]['ref'].outputTensors.index(tensor)

        #     assert len(g.node[succ]['ref'].outputTensorNames) == 1

        #     g.node[n]['ref'].outputTensorNames[out_tensor_idx] = g.node[succ]['ref'].outputTensorNames[0]
        #     g.node[n]['ref'].outputTensorSizes[out_tensor_idx] = g.node[succ]['ref'].outputTensorSizes[0]

        #     tensor_lst = list(g.node[n]['ref'].outputTensors)
        #     tensor_lst[out_tensor_idx] = g.node[succ]['ref'].outputTensors[0]
        #     g.node[n]['ref'].setOutputTensors(tensor_lst)

        g = nx.contracted_edge(g, (n, succ), self_loops=False)
        g.node[n].pop('contraction', None)

    return g, len(contraction_list) > 0

def contractSubgraph(g, start_subgraph, end_subgraph, subgraph):
    source = [name for name in subgraph.node if len(list(subgraph.predecessors(name))) == 0]
    sinks = [name for name in subgraph.node if len(list(subgraph.successors(name))) == 0]

    # Only one source in the opt graph
    assert len(source) == 1

    # Check that only one path exist between each source and sink
    assert all([len(list(nx.all_simple_paths(subgraph,source=source[0],target=sink))) == 1 for sink in sinks])

    # Do the contraction
    for sink in sinks:
        while sink != source[0]:
            pred = list(g.predecessors(sink))[0]
            g = nx.contracted_nodes(g, pred, sink, self_loops=False)
            sink = pred

    return g

def extractSubgraphs(g):
    '''
    This fuinction generates N subgraphs
    '''
    subgraphs = []
    for name in g.node:
        if type(g.node[name]['ref']) == Concat:
            pred_concat = []
            for pred in g.predecessors(name):
                ancestor = nx.ancestors(g,pred)
                pred_concat.append(set.union(ancestor, {pred}))

            # List all predecessors
            pred_lst = list(set.intersection(*pred_concat))
            start = min([(node, nx.shortest_path_length(g,node, name)) for node in pred_lst], key = lambda x: x[1])[0]

            for i, tt in enumerate(nx.all_simple_paths(g,source=start,target=name)):
                if i > 10:
                    break
            if i > 10:
                continue

            # Extract subgraph
            paths_between_generator = nx.all_simple_paths(g,source=start,target=name)
            sg = g.subgraph({node for path in paths_between_generator for node in path if node != name})

            # Remove implicit operations
            for n in sg.nodes:
                if sg.node[n]['ref'].getImplicit():
                    sg = nx.contracted_nodes(sg, list(g.predecessors(n))[0], n, self_loops=False)
            # Get the subgraph depth
            if (nx.dag_longest_path_length(sg) <= 3) and (nx.shortest_path_length(g,source=start, target=name) > 1) and all([sg.node[name]['ref'].isHW or isinstance(sg.node[name]['ref'], Concat) for name in sg.node]):
                subgraphs.append((sg, start, name))

    return subgraphs



def extractBranches(g):

    # Remove element with multiple child/parents
    edge_exclusion_list = []
    for name in g.node:
        if len(list(g.predecessors(name))) > 1:
            for pred in g.predecessors(name):
                edge_exclusion_list.append((pred, name))
        if len(list(g.successors(name))) > 1:
            for succ in g.successors(name):
                edge_exclusion_list.append((name,succ))
    # Remove all the edges
    g.remove_edges_from(edge_exclusion_list)

    # Remove non-hw layer
    node_exclusion_list = []
    for name in g.node:
        if not isHWLayer(g.node[name]['ref']):
            node_exclusion_list.append(name)
    g.remove_nodes_from(node_exclusion_list)

    return list(nx.connected_components(g.to_undirected()))


def newConnection(g, parentName, childName, new_layer,
                  childInputAlreadySet=False):
    """
        Inserts a new entry into the graph.
        childOutput already set tries to make sure they have the same output buffer

        @childInputAlreadySet - If True, will attempt to create buffers and NoOp layers.
            If False, it will just do simple attachments.
    """
    new_layer_name = new_layer.name.stringifyName()
    new_layer_original_name = new_layer.name.stringifyOriginalName()
    g.add_node(new_layer_name, type="OP", ref=new_layer)
    g.add_edge(parentName, new_layer_name)

    childLayer = g.node[childName]['ref']
    parentLayer = g.node[parentName]['ref']

    if not childInputAlreadySet:
        filler = Concat("CombineInputs", None, None)
        fillerName = filler.name.stringifyName()

        sameLevelNodes = list(g.predecessors(childName))

        g.add_node(fillerName, type="OP", ref=filler)
        g.add_edge(fillerName, childName)
        g.add_edge(new_layer_name, fillerName)

        new_out = UnpopulatedTensor(g.node[sameLevelNodes[0]]['ref'].getOutputTensors()[0].getShape())
        new_out.setName(MangledName(OriginalName(str(new_layer_original_name))))
        new_out.setLayout(Layouts.NHWC)

        new_layer_OT_ORIGINAL = new_layer.getOutputTensors()[0]
        new_layer.setOutputTensorsAllFields([new_out])

        ot_sln = g.node[sameLevelNodes[0]]['ref'].getOutputTensors()[0]
        containerTensor = UnpopulatedTensor(ot_sln.getTopEncloserRecursive().getShape())
        containerTensor.setLayout(Layouts.NHWC)
        containerTensor.setName(MangledName(OriginalName("inplace_accumulation")))

        filler.setInputTensors([])
        filler.loadInputTensorSizes([])
        filler.setInputTensorNames([])

        for slname in sameLevelNodes:
            slnode = g.node[slname]['ref']
            sln_orignal_name = g.node[slname]['ref'].name.stringifyOriginalName()
            old_output_slnode = slnode.getOutputTensors()[0]

            old_output_slnodeEnc = old_output_slnode.getTopEncloserRecursive()
            filler_in = UnpopulatedTensor(old_output_slnode.shape)
            filler_in.setLayout(Layouts.NHWC)
            filler_in.setName(MangledName(OriginalName(str(sln_orignal_name))))
            filler.appendInputTensorsAllFields([filler_in])
            slnode.setOutputTensorsAllFields([filler_in])
            g.add_edge(slname, fillerName)
            g.remove_edge(slname, childName)

            childLayer.removeInputTensorsAllFields([old_output_slnodeEnc])

        filler.appendInputTensorsAllFields([new_out])

        filler.setOutputTensorsAllFields([containerTensor])
        childLayer.appendInputTensorsAllFields([containerTensor])   # TODO: Remove

    else:

        childLayer = g.node[childName]['ref']
        succLayer = g.node[new_layer_name]['ref']

        childLayer.appendInputTensorsAllFields(succLayer.getOutputTensors())

        g.add_edge(new_layer_name, childName)

    return g


# Add a layer in between two node. Adjust tensors and edges
# Note: Requires a prior between parent and child connection
def addLayerInBetween(g, parentName, childName, new_layer_class, new_layer_name, preserve_layout=True):

    childLayer = g.node[childName]['ref']
    parentLayer = g.node[parentName]['ref']

    tensorNames = list(set.intersection(set(parentLayer.outputTensorNames), set(childLayer.inputTensorNames)))
    tensors = list(set.intersection(set(parentLayer.outputTensors), set(childLayer.inputTensors)))

    # Check for errors
    assert len(tensorNames) == len(tensors)
    assert len(tensorNames) == 1
    assert len(tensors) == 1

    # this is the tensor and the tensor name in common between the two layer
    inputTensor = tensors[0]
    inputTensorName = tensorNames[0].stringifyOriginalName()

    if preserve_layout:
        layout = childLayer.inputTensors[0].getLayout()

    # Create a new tensor for layout conversion
    ConvertedTensor = UnpopulatedTensor(shape = inputTensor.shape)
    for attr_name in inputTensor.__dict__:
        setattr(ConvertedTensor, attr_name, getattr(inputTensor, attr_name))
    if preserve_layout:
        ConvertedTensor.setLayout(layout)

    ConvertedTensor.setName(MangledName(OriginalName('{}_converted'.format(inputTensorName))))

    # Create the new layer
    convert_layer = new_layer_class(new_layer_name, [tensorNames[0]], [ConvertedTensor.getName()])
    convert_layer.setInputTensors([inputTensor])
    convert_layer.setOutputTensors([ConvertedTensor])

    # Same input and output size
    convert_layer.inputTensorSizes = childLayer.inputTensorSizes
    convert_layer.outputTensorSizes = childLayer.inputTensorSizes

    g.add_node(convert_layer.name.stringifyName(), type="OP", ref=convert_layer)
    g.add_edge(convert_layer.name.stringifyName(), childName)

    # The child needs to be set to the new (relative) parent
    childLayer.setInputTensors([ConvertedTensor])
    childLayer.setInputTensorNames([ConvertedTensor.name])
    childLayer.loadInputTensorSizes([ConvertedTensor.shape])

    # remove previous edge and add connection in and from
    if tensorNames[0] in g.node[parentName]['ref'].outputTensorNames:
        g.add_edge(parentName, convert_layer.name.stringifyName())
        g.remove_edge(parentName, childName)

    return g

def genOptNetwork(g):
    net = Network(g.name, None)
    for name in nx.lexicographical_topological_sort(g):
        net.stageslist.append(OptStage(g, name))
    # add tail
    for stage in net.stageslist:
        for name in stage.tail_names:
            stage.tail.extend([x for x in net.stageslist if get_null_terminating_name(x.name) == name])

    return net

def debug_graph(g):
    for name in nx.lexicographical_topological_sort(g):
        print('--------------')
        print('name', name)
        node = g.node[name]['ref']
        print(type(node))
        print('predecessors', list(g.predecessors(name)))
        print('successors', list(g.successors(name)))
        if g.node[name]['type'] == 'OP':
            print('input tensor', [x.stringifyName() for x in node.inputTensorNames], "TopEncloser:", [x.getTopEncloserRecursive().name.stringifyName() for x in node.inputTensors], node.inputTensorSizes)
            print('output tensor', [x.stringifyName() for x in node.outputTensorNames], "TopEncloser:", [x.getTopEncloserRecursive().name.stringifyName() for x in node.outputTensors] ,  node.outputTensorSizes)
            if 'contraction' in g.node[name].keys():
                print('Contractions', g.node[name]['contraction'])
        else:
            print('shape', node.shape)
            if hasattr(node, 'layout'):
                print('layout', node.layout)

def isHWLayer(layer):
    return layer.isHW

def isInPlace(layer):
    if isinstance(layer, ReLU):
        return True
    return False

def isNonOvlPooling(layer):
    if isinstance(layer, HwPooling):
        if (layer.kernelHeight <= layer.strideHeight) and (layer.kernelWidth <= layer.strideWidth):
            return True
    return False


def convertLayout(layout):
    encodedLayout = {
        Layouts.NHCW : 'I',
        Layouts.NCHW : 'P'
    }
    return encodedLayout[layout]

# Optimization Stage
class OptStage():
    def __init__(self, graph, name):
        self.g = graph
        self.name = str.encode(name)
        self.tail_names = list(self.g.successors(name))
        self.tail = []
        self.top = list(self.g.predecessors(name))
        self.layer = self.g.node[name]['ref']
        self.op = self.getOp()

        self.inputDimZ = 0
        self.inputDimX = 0
        self.inputDimY = 0
        self.outputDimZ = 0
        self.outputDimX = 0
        self.outputDimY = 0


        if self.op in [StageType.convolution, StageType.fully_connected_layer]:
            self.bias = None
            if self.layer.biasEnabled():
                self.bias = self.layer.getBias().data

            # Convert to hwck for hardwerize compatibility
            if self.op == StageType.convolution:
                self.taps = np.transpose(self.layer.getWeights().data, (2, 3, 1, 0))
            else:
                self.taps = np.transpose(self.layer.getWeights().data, (0, 1, 3, 2))
            # TODO: Implement ME!!
            self.scale = None

        for tensor in self.layer.inputTensors:
            size = tensor.getShape()#tensor.getTopEncloserRecursive().getShape()
            self.inputDimZ  += size[1]
            self.inputDimX  += size[3]
            self.inputDimY  += size[2]

        for tensor in self.layer.outputTensors:
            size = tensor.getTopEncloserRecursive().getShape()
            self.outputDimZ += size[1]
            self.outputDimX += size[3]
            self.outputDimY += size[2]

        if  self.op in [StageType.convolution, StageType.average_pooling, StageType.max_pooling]:

            self.radixX = self.layer.kernelWidth
            self.radixY = self.layer.kernelHeight
            self.strideX = self.layer.strideWidth
            self.strideY = self.layer.strideHeight
            self.padX = self.layer.paddingWidth
            self.padY = self.layer.paddingHeight

        if self.op == StageType.fully_connected_layer:
            s = self.layer.inputTensors[0].getTopEncloserRecursive().getShape()
            if len(s) - 1 != s.count(1):
            # if len(np.squeeze(s)) > 1:
                self.inputDimZ *= self.inputDimX * self.inputDimY
                self.inputDimX = 1
                self.inputDimY = 1
                raise ValueError("Cannot support 3D input for HW FC")

        if isinstance(self.layer, HwConvolutionPooling):
            self.fused_conv_pooling = True
            self.fused_poolingRadixX = self.layer.pooling_kernelWidth
            self.fused_poolingRadixY = self.layer.pooling_kernelHeight
            self.fused_poolingStrideX = self.layer.pooling_strideWidth
            self.fused_poolingStrideY = self.layer.pooling_strideHeight
        else:
            self.fused_conv_pooling = False

    def getOp(self):
        if isinstance(self.layer, HwConvolution) or isinstance(self.layer, HwConvolutionPooling):
            return StageType.convolution
        elif isinstance(self.layer, HwPooling):
            if self.layer.type == Pooling.Type.MAX:
                return StageType.max_pooling
            else:
                return StageType.average_pooling
        elif isinstance(self.layer, HwFC):
            return StageType.fully_connected_layer
        else:
            # raise ValueError("Try to schedule non hw layer: {}".format(type(self.layer)))
            return None
