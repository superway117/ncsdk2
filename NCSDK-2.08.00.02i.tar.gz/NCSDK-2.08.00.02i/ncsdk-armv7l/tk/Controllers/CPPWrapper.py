

import sys
import os
from Controllers.GraphUtils import buildGraph
import networkx as nx
import numpy as np

def CPP_INTERCEPT(parsedLayers):

    base = os.environ.get('MCM_HOME')
    ldlib = os.environ.get('LD_LIBRARY_PATH')
    if base is None:
        print("Please set enviroment path MCM_HOME. Exiting...")
        quit()
    if ldlib is None:
        print("Please set your LD_LIBRARY_PATH enviroment variable correctly. Exiting...")
        quit()
    sys.path.append(base + '/python/api')

    import composition_api as ca

    reference_list = {}
    compUnit = ca.getCompilationUnit()
    om = ca.getModel(compUnit)

    g = buildGraph(parsedLayers)

    for index, child in enumerate(nx.lexicographical_topological_sort(g)):
        layer = g.node[child]['ref']
        n = layer.name.stringifyName()
        reference_list[n], om = buildOM(g, child, reference_list, om)

    ca.compile(compUnit)


def buildOM(g, gnode_name, reflist, om):
    """
        Construct C++ Representation of a Layer.
        Return the iterator for passing forward
    """

    base = os.environ.get('MCM_HOME')
    ldlib = os.environ.get('LD_LIBRARY_PATH')
    if base is None:
        print("Please set enviroment path MCM_HOME. Exiting...")
        quit()
    if ldlib is None:
        print("Please set your LD_LIBRARY_PATH enviroment variable correctly. Exiting...")
        quit()
    sys.path.append(base + '/python/api')

    import composition_api as ca

    gnode = g.node[gnode_name]

    l = gnode['ref']

    from Controllers.Parsers.Parser.InnerProduct import InnerProduct
    from Controllers.Parsers.Parser.Input import Input
    from Controllers.Parsers.Parser.Output import Output
    from Controllers.Parsers.Parser.Convolution2D import Convolution2D
    from Controllers.Parsers.Parser.Pooling import Pooling
    from Controllers.Parsers.Parser.Eltwise import Eltwise
    from Controllers.Parsers.Parser.ReLU import ReLU
    from Controllers.Parsers.Parser.Scale import Scale
    from Controllers.Parsers.Parser.Bias import Bias
    from Controllers.Parsers.Parser.BatchNorm import BatchNorm
    from Controllers.Parsers.Parser.Softmax import Softmax

    _ref = None

    if isinstance(l, Bias):
        assert 0, "Standalone Bias Layer currently unsupported by C++ API"

    if isinstance(l, Input):
        s = l.getOutputTensors()[0].getShape()
        shape = ca.getShape(s[3], s[2], s[1])
        _ref = ca.input(om, shape)

    elif isinstance(l, Output):
        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]
        _ref = ca.output(om, in_)

    elif isinstance(l, Pooling):
        # TODO: Ave + Max
        if l.getType() == Pooling.Type.MAX:

            pred = list(g.predecessors(gnode_name))
            in_ = reflist[pred[0]]

            ry, rx = l.getKernelSize()
            sy, sx = l.getStride()
            py, px = l.getPadding()

            _ref = ca.maxpool2D_caffe(om, in_, rx, ry, sx, sy, px, py)

        elif l.getType() == Pooling.Type.AVE:

            pred = list(g.predecessors(gnode_name))
            in_ = reflist[pred[0]]

            ry, rx = l.getKernelSize()
            sy, sx = l.getStride()
            py, px = l.getPadding()

            _ref = ca.avgpool2D_caffe(om, in_, rx, ry, sx, sy, px, py)

    elif isinstance(l, ReLU):

        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]

        _ref = ca.relu(om, in_)

    elif isinstance(l, Eltwise):
        if l.getType() == Eltwise.Type.WSUM:
            pred = list(g.predecessors(gnode_name))
            in1_ = reflist[pred[0]]
            if len(pred) == 1:
                in2_ = reflist[pred[0]]  # Same input.
            else:
                in2_ = reflist[pred[1]]

            _ref = ca.add(om, in1_, in2_)

        elif l.getType() == Eltwise.Type.WPROD:
            pred = list(g.predecessors(gnode_name))
            in1_ = reflist[pred[0]]
            in2_ = reflist[pred[1]]

            _ref = ca.multiply(om, in1_, in2_)

    elif isinstance(l, Scale):

        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]

        scale_data = l.getMultiplier()
        scale_vector = ca.getData(scale_data.astype(np.float32))
        scale_param = ca.constant(om, scale_vector, ca.getShape(scale_data.shape[0]))
        scale = ca.scale(om, in_, scale_param)

        if l.getBiasBeta() is not None:
            bias_data = l.getBiasBeta()
            bias_vector = ca.getData(bias_data.astype(np.float32))
            bias_param = ca.constant(om, bias_vector, ca.getShape(bias_data.shape[0]))
            bias = ca.bias(om, scale, bias_param)
            _ref = bias
        else:
            _ref = scale

    elif isinstance(l, BatchNorm):

        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]

        '''mean_data = ca.getData(l.getMean().astype(np.float32))
        mean_param = ca.constant(om, mean_data, ca.getShape(*l.getMean().shape))

        var_data = ca.getData(l.getVariance().astype(np.float32))
        variance_param = ca.constant(om, var_data, ca.getShape(*l.getVariance().shape))

        offset_data = ca.getData(l.getBiasBeta().astype(np.float32))
        offset_param = ca.constant(om, offset_data, ca.getShape(*l.getBiasBeta().shape))

        scale_data = ca.getData(l.getMultiplier().astype(np.float32))
        scale_param = ca.constant(om, scale_data, ca.getShape(*l.getMultiplier().shape))

        eps = l.getEPS()

        _ref = ca.batchNorm(om, in_, mean_param, variance_param, offset_param, scale_param, eps)'''

        scale_data = l.getMultiplier()
        scale_vector = ca.getData(scale_data.astype(np.float32))
        scale_param = ca.constant(om, scale_vector, ca.getShape(scale_data.shape[0]))
        scale = ca.scale(om, in_, scale_param)

        bias_data = l.getBiasBeta()
        bias_vector = ca.getData(bias_data.astype(np.float32))
        bias_param = ca.constant(om, bias_vector, ca.getShape(bias_data.shape[0]))
        bias = ca.bias(om, scale, bias_param)
        _ref = bias

    elif isinstance(l, Softmax):

        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]

        _ref = ca.softmax(om, in_)

    elif isinstance(l, InnerProduct):

        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]

        w_data = l.getWeights().data
        w_orig = w_data

        w_data = np.transpose(w_data, (2, 3, 1, 0))
        arr = w_data.flatten()
        weight_data = ca.getData(np.array(arr).astype(np.float32))

        weights_ = ca.constant(om, weight_data, ca.getShape(w_orig.shape[3], w_orig.shape[2]))
        fc = ca.fullyConnected(om, in_, weights_)

        if l.biasEnabled():
            b = l.getBias()
            bias_data = ca.getData(np.array(b.data.flatten()).astype(np.float32))
            bias = ca.constant(om, bias_data, ca.getShape(b.shape[3]))
            _ref = ca.bias(om, fc, bias)
        else:
            _ref = fc

    elif isinstance(l, Convolution2D):
        pred = list(g.predecessors(gnode_name))
        in_ = reflist[pred[0]]

        w_data = l.getWeights().data
        w_orig = w_data

        w_data = np.transpose(w_data, (2, 3, 1, 0))
        arr = w_data.flatten()

        weights_data = ca.getData(np.array(arr).astype(np.float32))

        weights_param = ca.constant(om, weights_data, ca.getShape(w_orig.shape[3], w_orig.shape[2], w_orig.shape[1], w_orig.shape[0]))
        (sY, sX) = l.getStrideSize()
        (pY, pX) = l.getPadding()

        _conv = ca.conv2D_caffe(om, in_, weights_param, sX, sY, pX, pY)

        if l.biasEnabled():
            b = l.getBias()
            bias_data = ca.getData(np.array(b.data.flatten()).astype(np.float32))
            bias = ca.constant(om, bias_data, ca.getShape(b.shape[3]))
            _ref = ca.bias(om, _conv, bias)
        else:
            _ref = _conv

    else:
        print("NOT FOUND")

    assert _ref is not None, "layer unsupported for C++ Conversion" + str(type(l))
    return _ref, om
